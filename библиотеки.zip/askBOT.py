SYMBOLS = [',', '.', '!', '?', '-']

def separate_message(row):
    stroka = ''
    words = []
    
    for char in row:
        stroka = stroka + char

        if stroka.lower() == "как" or stroka.lower() == "дела" or stroka.lower() == "привет" or stroka.lower() == "здорово" or stroka.lower() == "пока" or stroka.lower() == "до" or stroka.lower() == "встречи":
            words.append(stroka.lower())

        if char == ' ' or char == ',' or char == '.' or char == '!' or char == ';' or char == "?":
            stroka = ''

    stroka1 = ''
    for n in range(len(words)):
        if stroka1 != '':
            stroka1 = stroka1 + ' '
        if words[n] != "привет" and words[n] != "здарова" and words[n] != "пока":
            stroka1 = stroka1 + words[n]

    if stroka1 == "как дела":
        words.append(stroka1)
    if stroka1 == "до встречи":
        words.append(stroka1)

    slovo = ''
    for item in words:
        if item == "как дела" :
            slovo = item 
        elif (item == "привет" or item == "здорово" or item == "пока" or item == "до встречи") and slovo != "как дела":
            slovo = item

    return slovo

def separate_words(spisok0, n = 0, symbols = SYMBOLS):
    spisok = []
    for sym in spisok0:
        words = sym.split(symbols[n])
        for word in words:
            if word != '':
                spisok.append(word)

    if n < len(SYMBOLS) - 1:
        spisok = separate_words(spisok, n + 1)
    
    return spisok


def separate_message(row):
    spisok = row.split(" ")
    spisok = separate_words(spisok)

    return spisok