import datetime as d
import random as r

DATE_TODAY = str(d.datetime.today())

def days(tuple):
    year, month, day = tuple
    s = 0
    d = 31
    for m in range(month-1):
        if m <= 6:
            if m % 2 == 0:
                d = 31
            elif m % 2 != 0 and m!= 1:
                d = 30
            elif m == 1:
                d = 28 + 0 ** (year % 4)
        if m > 6:
            if m % 2 == 0:
                d = 30
            elif m % 2 != 0:
                d = 31
        s = s + d
    day = s + day
    return year, day

def date(tuple):
    year, day = tuple
    m = 0
    d = 31
    while day > d:
        if m <= 6:
            if m % 2 == 0:
                d = 31
            elif m % 2 != 0 and m!= 1:
                d = 30
            elif m == 1:
                d = 28 + 0 ** (year % 4)
        if m > 6:
            if m % 2 == 0:
                d = 30
            elif m % 2 != 0:
                d = 31
        day -= d
        m += 1
        if m > 11:
            year += (m + 1) // 12
            m = (m + 1) % 12 - 1
    month = m + 1
    return year, month, day


def date_str(str, i=0):
    try:
        day = int(str[-2-i] + str[-1-i])
    except:
        day = int(str[-1-i])
    try:
        month = int(str[-5-i] + str[-4-i])
    except:
        month = int(str[-4-i])
    year = int(str[-10-i] + str[-9-i] + str[-8-i] + str[-7-i])
    return year, month, day

def str_time(tuple):
    year, month, day = tuple
    znak = ""

    if day <= 0 and month <= 0 and year <= 0:
        year = -1 * year
        month = -1 * month
        day = -1 * day
        znak = "-"

    month -= 1

    if year == 0 and month == 0 and day == 0:
        time = "сегодня"

    elif year == 0 and month == 0 and day == 1:
        if znak == "":
            time = "завтра"
        elif znak == "-":
            time = "вчера"

    else:
        if day != 0:
            day -= 1


        dName = "дней"

        if day // 10 % 10 != 1:
            if day % 10 == 1:
                dName = "день"
            for x in range(2, 5):
                if day % 10 == x:
                    dName = "дня"
        if day == 0:
            day = ""
            dName = ""

        if len(dName) > 0:
            day = str(day) + " "


        mName = "месяцев"
        if month // 10 % 10 != 1:
            if month % 10 == 1:
                mName = "месяц"
            for x in range(2, 5):
                if month % 10 == x:
                    mName = "месяца"
        if month == 0:
            month = ""
            mName = ""

        if len(mName) > 0:
            month = str(month) + " "

            if len(dName) > 0:
                mName = mName + " "


        yName = "лет"
        if year // 10 % 10 != 1:
            if year % 10 == 1:
                yName = "год"
            for x in range(2, 5):
                if year % 10 == x:
                    yName = "года"
        if year == 0:
            year = ""
            yName = ""

        if len(yName) > 0:
            year = str(year) + " "

            if len(mName) > 0 or len(dName) > 0:
                yName = yName + " "
        if znak == "":
            time = "через " + year + yName + month + mName + day + dName
        elif znak == "-":
            time = year + yName + month + mName + day + dName + " назад"
        
    return time


def DatesMinus(tuple, day):
    year, day1 = days(tuple)
    while day1 < day:
        year-=1
        day1 = day1 + 365 + 0 ** ((year-1) % 4)
    day1 = day1 - day
    tuple1 = year, day1
    year, month, day = date(tuple1)
    return year, month, day

def DatesPlus(tuple, day):
    year, day1 = days(tuple)
    day1 = day1 + day
    dayYear = 365 + 0 ** (year % 4)
    while day1 > dayYear:
        dayYear = 365 + 0 ** (year % 4)
        day1 = day1 - dayYear
        year+=1
    tuple1 = year, day1
    year, month, day = date(tuple1)
    return year, month, day



def ifDates(tuple1, tuple2):
    year1, day1 = days(tuple1)
    year2, day2 = days(tuple2)

    if year1 > year2:
        boolean = True
    elif year1 < year2:
        boolean = False
    elif year1 == year2:
        if day1 >= day2:
            boolean = True
        elif day1 < day2:
            boolean = False

    return boolean

def DifferDate(tuple1, tuple2):
    year1, day1 = days(tuple1)
    year2, day2 = days(tuple2)

    znak = 1
    if year2 < year1:
        d = year2
        year2 = year1
        year1 = d

        d = day2
        day2 = day1
        day1 = d

        znak = -1

    elif year1 == year2 and day2 < day1:
        d = day2
        day2 = day1
        day1 = d

        znak = -1
    
    if day2 < day1:
        day2 = 365 + 0 ** (year2 % 4)
        year2 -= 1

    year = year2 - year1
    day = day2 - day1

    tuple = year, day
    year, month, day = date(tuple)
    year = znak * year
    month = znak * month
    day = znak * day

    return year, month, day


def time_str(date_today = DATE_TODAY):
    time = date_today.split(" ")
    time = time[-1].split(":")

    time1 = time[0]
    time2 = time[1]
    time3 = time[2]

    try:
        hour = int(time1)
    except:
        hour = int(time1[1])
    try:
        minuts = int(time2)
    except:
        minuts = int(time2[1])
    try:
        seconds = int(time3[:2])
    except:
        seconds = int(time3[1])

    return hour, minuts, seconds

def timeALARM(time = time_str()):
    hour = time[0]
    if hour >= 0 and hour < 6:
        alarmHELLO = "добрая ночь"
        alarmBYE = r.choice(["спокойной ночи", "добрых снов", "счастливой ночи", "доброй ночи"])

    elif hour >= 6 and hour < 12:
        alarmHELLO = "доброе утро"
        alarmBYE = r.choice(["удачного дня", "до новой встречи"])

    elif hour >= 12 and hour < 18:
        alarmHELLO = "добрый день"
        alarmBYE = r.choice(["удачного дня", "до новой встречи"])
        if r.randrange(5) == 3:
            alarmHELLO = r.choice(["привет", "здорово"])

    elif hour >= 18:
        alarmHELLO = "добрый вечер"
        alarmBYE = r.choice(["счастливого вечера", "до новой встречи"])
        if r.randrange(5) == 3:
            alarmHELLO = r.choice(["привет", "здорово"])

    return alarmHELLO, alarmBYE